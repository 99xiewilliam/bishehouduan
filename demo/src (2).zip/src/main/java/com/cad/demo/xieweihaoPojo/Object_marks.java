package com.cad.demo.xieweihaoPojo;

import java.util.List;

public class Object_marks {
    private String object_type;
    private List<Object> objects;


    public String getObject_type() {
        return object_type;
    }

    public void setObject_type(String object_type) {
        this.object_type = object_type;
    }

    public void setObjects(List<Object> objects) {
        this.objects = objects;
    }


    public List<Object> getObjects() {
        return objects;
    }


}
